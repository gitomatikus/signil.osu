window.songInfo = '{\n' +
    '\t"data" : \n' +
    '\t{\n' +
    '\t\t"approved" : 1,\n' +
    '\t\t"approved_date" : 1525484440,\n' +
    '\t\t"artist" : "toby fox",\n' +
    '\t\t"artistU" : "",\n' +
    '\t\t"bid_data" : \n' +
    '\t\t[\n' +
    '\t\t\t{\n' +
    '\t\t\t\t"AR" : 9.0,\n' +
    '\t\t\t\t"CS" : 4.0,\n' +
    '\t\t\t\t"HP" : 6.0,\n' +
    '\t\t\t\t"OD" : 8.0,\n' +
    '\t\t\t\t"aim" : 2.42,\n' +
    '\t\t\t\t"audio" : "audio.mp3",\n' +
    '\t\t\t\t"bg" : "spiderdance.jpg",\n' +
    '\t\t\t\t"bid" : 1580330,\n' +
    '\t\t\t\t"circles" : 205,\n' +
    '\t\t\t\t"hit300window" : 0,\n' +
    '\t\t\t\t"img" : "0",\n' +
    '\t\t\t\t"length" : 101,\n' +
    '\t\t\t\t"maxcombo" : 625,\n' +
    '\t\t\t\t"mode" : 0,\n' +
    '\t\t\t\t"passcount" : 112968,\n' +
    '\t\t\t\t"playcount" : 965358,\n' +
    '\t\t\t\t"pp" : 159.8,\n' +
    '\t\t\t\t"pp_acc" : 50.56,\n' +
    '\t\t\t\t"pp_aim" : 59.86,\n' +
    '\t\t\t\t"pp_speed" : 59.86,\n' +
    '\t\t\t\t"sliders" : 199,\n' +
    '\t\t\t\t"speed" : 2.142,\n' +
    '\t\t\t\t"spinners" : 0,\n' +
    '\t\t\t\t"star" : 4.787,\n' +
    '\t\t\t\t"strain_aim" : "243322231344423333432332332332234441000001232333222",\n' +
    '\t\t\t\t"strain_speed" : "023212321123112323222121220234444222030000332213312",\n' +
    '\t\t\t\t"version" : "cheesiest\'s Insane"\n' +
    '\t\t\t},\n' +
    '\t\t\t{\n' +
    '\t\t\t\t"AR" : 8.5,\n' +
    '\t\t\t\t"CS" : 4.0,\n' +
    '\t\t\t\t"HP" : 5.0,\n' +
    '\t\t\t\t"OD" : 7.0,\n' +
    '\t\t\t\t"aim" : 2.222,\n' +
    '\t\t\t\t"audio" : "audio.mp3",\n' +
    '\t\t\t\t"bg" : "spiderdance.jpg",\n' +
    '\t\t\t\t"bid" : 1580331,\n' +
    '\t\t\t\t"circles" : 97,\n' +
    '\t\t\t\t"hit300window" : 0,\n' +
    '\t\t\t\t"img" : "0",\n' +
    '\t\t\t\t"length" : 101,\n' +
    '\t\t\t\t"maxcombo" : 563,\n' +
    '\t\t\t\t"mode" : 0,\n' +
    '\t\t\t\t"passcount" : 261972,\n' +
    '\t\t\t\t"playcount" : 1333611,\n' +
    '\t\t\t\t"pp" : 102.3,\n' +
    '\t\t\t\t"pp_acc" : 26.54,\n' +
    '\t\t\t\t"pp_aim" : 41.76,\n' +
    '\t\t\t\t"pp_speed" : 41.76,\n' +
    '\t\t\t\t"sliders" : 219,\n' +
    '\t\t\t\t"speed" : 1.826,\n' +
    '\t\t\t\t"spinners" : 0,\n' +
    '\t\t\t\t"star" : 4.276,\n' +
    '\t\t\t\t"strain_aim" : "234234033412422233434343344442320211002121212000000",\n' +
    '\t\t\t\t"strain_speed" : "123113012301321121212321344430220101000101102000000",\n' +
    '\t\t\t\t"version" : "cheesiest\'s Light Insane"\n' +
    '\t\t\t},\n' +
    '\t\t\t{\n' +
    '\t\t\t\t"AR" : 3.3,\n' +
    '\t\t\t\t"CS" : 2.0,\n' +
    '\t\t\t\t"HP" : 2.5,\n' +
    '\t\t\t\t"OD" : 2.5,\n' +
    '\t\t\t\t"aim" : 0.8547,\n' +
    '\t\t\t\t"audio" : "audio.mp3",\n' +
    '\t\t\t\t"bg" : "spiderdance.jpg",\n' +
    '\t\t\t\t"bid" : 1580332,\n' +
    '\t\t\t\t"circles" : 28,\n' +
    '\t\t\t\t"hit300window" : 0,\n' +
    '\t\t\t\t"img" : "0",\n' +
    '\t\t\t\t"length" : 99,\n' +
    '\t\t\t\t"maxcombo" : 279,\n' +
    '\t\t\t\t"mode" : 0,\n' +
    '\t\t\t\t"passcount" : 204057,\n' +
    '\t\t\t\t"playcount" : 367092,\n' +
    '\t\t\t\t"pp" : 6.16,\n' +
    '\t\t\t\t"pp_acc" : 2.77,\n' +
    '\t\t\t\t"pp_aim" : 2.16,\n' +
    '\t\t\t\t"pp_speed" : 2.16,\n' +
    '\t\t\t\t"sliders" : 80,\n' +
    '\t\t\t\t"speed" : 0.6247,\n' +
    '\t\t\t\t"spinners" : 1,\n' +
    '\t\t\t\t"star" : 1.59,\n' +
    '\t\t\t\t"strain_aim" : "242333434344422414234444421334444343000000000000000",\n' +
    '\t\t\t\t"strain_speed" : "031444314134412314142341421123144144000000000000000",\n' +
    '\t\t\t\t"version" : "Easy"\n' +
    '\t\t\t},\n' +
    '\t\t\t{\n' +
    '\t\t\t\t"AR" : 7.8,\n' +
    '\t\t\t\t"CS" : 4.0,\n' +
    '\t\t\t\t"HP" : 4.5,\n' +
    '\t\t\t\t"OD" : 6.0,\n' +
    '\t\t\t\t"aim" : 1.903,\n' +
    '\t\t\t\t"audio" : "audio.mp3",\n' +
    '\t\t\t\t"bg" : "spiderdance.jpg",\n' +
    '\t\t\t\t"bid" : 1580333,\n' +
    '\t\t\t\t"circles" : 112,\n' +
    '\t\t\t\t"hit300window" : 0,\n' +
    '\t\t\t\t"img" : "0",\n' +
    '\t\t\t\t"length" : 101,\n' +
    '\t\t\t\t"maxcombo" : 547,\n' +
    '\t\t\t\t"mode" : 0,\n' +
    '\t\t\t\t"passcount" : 211824,\n' +
    '\t\t\t\t"playcount" : 1089153,\n' +
    '\t\t\t\t"pp" : 58.05,\n' +
    '\t\t\t\t"pp_acc" : 18.21,\n' +
    '\t\t\t\t"pp_aim" : 25.65,\n' +
    '\t\t\t\t"pp_speed" : 25.65,\n' +
    '\t\t\t\t"sliders" : 182,\n' +
    '\t\t\t\t"speed" : 1.415,\n' +
    '\t\t\t\t"spinners" : 0,\n' +
    '\t\t\t\t"star" : 3.552,\n' +
    '\t\t\t\t"strain_aim" : "034401000244110344332423232443410110120121222212200",\n' +
    '\t\t\t\t"strain_speed" : "023312002333220133212334312433233130201442443444300",\n' +
    '\t\t\t\t"version" : "Hard"\n' +
    '\t\t\t},\n' +
    '\t\t\t{\n' +
    '\t\t\t\t"AR" : 9.4,\n' +
    '\t\t\t\t"CS" : 4.2,\n' +
    '\t\t\t\t"HP" : 6.0,\n' +
    '\t\t\t\t"OD" : 8.0,\n' +
    '\t\t\t\t"aim" : 3.003,\n' +
    '\t\t\t\t"audio" : "audio.mp3",\n' +
    '\t\t\t\t"bg" : "spiderdance.jpg",\n' +
    '\t\t\t\t"bid" : 1580334,\n' +
    '\t\t\t\t"circles" : 280,\n' +
    '\t\t\t\t"hit300window" : 0,\n' +
    '\t\t\t\t"img" : "0",\n' +
    '\t\t\t\t"length" : 101,\n' +
    '\t\t\t\t"maxcombo" : 699,\n' +
    '\t\t\t\t"mode" : 0,\n' +
    '\t\t\t\t"passcount" : 15480,\n' +
    '\t\t\t\t"playcount" : 232353,\n' +
    '\t\t\t\t"pp" : 239.5,\n' +
    '\t\t\t\t"pp_acc" : 55.51,\n' +
    '\t\t\t\t"pp_aim" : 112.0,\n' +
    '\t\t\t\t"pp_speed" : 112.0,\n' +
    '\t\t\t\t"sliders" : 200,\n' +
    '\t\t\t\t"speed" : 2.494,\n' +
    '\t\t\t\t"spinners" : 0,\n' +
    '\t\t\t\t"star" : 5.799,\n' +
    '\t\t\t\t"strain_aim" : "131242223331133323333442234443233120010232222334000",\n' +
    '\t\t\t\t"strain_speed" : "012122221212122211121211112342121110220022112223000",\n' +
    '\t\t\t\t"version" : "kevincela\'s Extra"\n' +
    '\t\t\t},\n' +
    '\t\t\t{\n' +
    '\t\t\t\t"AR" : 9.3,\n' +
    '\t\t\t\t"CS" : 4.0,\n' +
    '\t\t\t\t"HP" : 6.0,\n' +
    '\t\t\t\t"OD" : 9.0,\n' +
    '\t\t\t\t"aim" : 2.882,\n' +
    '\t\t\t\t"audio" : "audio.mp3",\n' +
    '\t\t\t\t"bg" : "spiderdance.jpg",\n' +
    '\t\t\t\t"bid" : 1580335,\n' +
    '\t\t\t\t"circles" : 285,\n' +
    '\t\t\t\t"hit300window" : 0,\n' +
    '\t\t\t\t"img" : "0",\n' +
    '\t\t\t\t"length" : 101,\n' +
    '\t\t\t\t"maxcombo" : 683,\n' +
    '\t\t\t\t"mode" : 0,\n' +
    '\t\t\t\t"passcount" : 39870,\n' +
    '\t\t\t\t"playcount" : 319914,\n' +
    '\t\t\t\t"pp" : 267.0,\n' +
    '\t\t\t\t"pp_acc" : 84.92,\n' +
    '\t\t\t\t"pp_aim" : 108.5,\n' +
    '\t\t\t\t"pp_speed" : 108.5,\n' +
    '\t\t\t\t"sliders" : 151,\n' +
    '\t\t\t\t"speed" : 2.595,\n' +
    '\t\t\t\t"spinners" : 0,\n' +
    '\t\t\t\t"star" : 5.741,\n' +
    '\t\t\t\t"strain_aim" : "143213401241214402333443200332333200111111231113300",\n' +
    '\t\t\t\t"strain_speed" : "132022322232023312211111200343211212101224212342100",\n' +
    '\t\t\t\t"version" : "Yoeri\'s Extra"\n' +
    '\t\t\t},\n' +
    '\t\t\t{\n' +
    '\t\t\t\t"AR" : 5.0,\n' +
    '\t\t\t\t"CS" : 3.5,\n' +
    '\t\t\t\t"HP" : 4.0,\n' +
    '\t\t\t\t"OD" : 5.0,\n' +
    '\t\t\t\t"aim" : 1.196,\n' +
    '\t\t\t\t"audio" : "audio.mp3",\n' +
    '\t\t\t\t"bg" : "spiderdance.jpg",\n' +
    '\t\t\t\t"bid" : 1580336,\n' +
    '\t\t\t\t"circles" : 68,\n' +
    '\t\t\t\t"hit300window" : 0,\n' +
    '\t\t\t\t"img" : "0",\n' +
    '\t\t\t\t"length" : 101,\n' +
    '\t\t\t\t"maxcombo" : 355,\n' +
    '\t\t\t\t"mode" : 0,\n' +
    '\t\t\t\t"passcount" : 317979,\n' +
    '\t\t\t\t"playcount" : 958815,\n' +
    '\t\t\t\t"pp" : 21.06,\n' +
    '\t\t\t\t"pp_acc" : 10.31,\n' +
    '\t\t\t\t"pp_aim" : 6.97,\n' +
    '\t\t\t\t"pp_speed" : 6.97,\n' +
    '\t\t\t\t"sliders" : 113,\n' +
    '\t\t\t\t"speed" : 0.9213,\n' +
    '\t\t\t\t"spinners" : 0,\n' +
    '\t\t\t\t"star" : 2.255,\n' +
    '\t\t\t\t"strain_aim" : "324344434243444314434443332334312120444334444300000",\n' +
    '\t\t\t\t"strain_speed" : "343244324432443234443333222343323230334344343200000",\n' +
    '\t\t\t\t"version" : "Yoeri\'s Normal"\n' +
    '\t\t\t},\n' +
    '\t\t\t{\n' +
    '\t\t\t\t"AR" : 9.5,\n' +
    '\t\t\t\t"CS" : 4.2,\n' +
    '\t\t\t\t"HP" : 6.0,\n' +
    '\t\t\t\t"OD" : 9.2,\n' +
    '\t\t\t\t"aim" : 3.251,\n' +
    '\t\t\t\t"audio" : "audio.mp3",\n' +
    '\t\t\t\t"bg" : "spiderdance.jpg",\n' +
    '\t\t\t\t"bid" : 1582339,\n' +
    '\t\t\t\t"circles" : 264,\n' +
    '\t\t\t\t"hit300window" : 0,\n' +
    '\t\t\t\t"img" : "0",\n' +
    '\t\t\t\t"length" : 101,\n' +
    '\t\t\t\t"maxcombo" : 742,\n' +
    '\t\t\t\t"mode" : 0,\n' +
    '\t\t\t\t"passcount" : 26937,\n' +
    '\t\t\t\t"playcount" : 299367,\n' +
    '\t\t\t\t"pp" : 321.8,\n' +
    '\t\t\t\t"pp_acc" : 90.26,\n' +
    '\t\t\t\t"pp_aim" : 146.5,\n' +
    '\t\t\t\t"pp_speed" : 146.5,\n' +
    '\t\t\t\t"sliders" : 197,\n' +
    '\t\t\t\t"speed" : 2.624,\n' +
    '\t\t\t\t"spinners" : 0,\n' +
    '\t\t\t\t"star" : 6.218,\n' +
    '\t\t\t\t"strain_aim" : "233224333332333222212233344421201212122222312200000",\n' +
    '\t\t\t\t"strain_speed" : "133223221332223211111123234420100122133322333340000",\n' +
    '\t\t\t\t"version" : "Kyshiro\'s Extreme"\n' +
    '\t\t\t},\n' +
    '\t\t\t{\n' +
    '\t\t\t\t"AR" : 9.6,\n' +
    '\t\t\t\t"CS" : 3.5,\n' +
    '\t\t\t\t"HP" : 6.0,\n' +
    '\t\t\t\t"OD" : 9.3,\n' +
    '\t\t\t\t"aim" : 3.714,\n' +
    '\t\t\t\t"audio" : "audio.mp3",\n' +
    '\t\t\t\t"bg" : "spiderdance.jpg",\n' +
    '\t\t\t\t"bid" : 1584604,\n' +
    '\t\t\t\t"circles" : 360,\n' +
    '\t\t\t\t"hit300window" : 0,\n' +
    '\t\t\t\t"img" : "0",\n' +
    '\t\t\t\t"length" : 101,\n' +
    '\t\t\t\t"maxcombo" : 776,\n' +
    '\t\t\t\t"mode" : 0,\n' +
    '\t\t\t\t"passcount" : 24813,\n' +
    '\t\t\t\t"playcount" : 548946,\n' +
    '\t\t\t\t"pp" : 423.1,\n' +
    '\t\t\t\t"pp_acc" : 103.3,\n' +
    '\t\t\t\t"pp_aim" : 217.9,\n' +
    '\t\t\t\t"pp_speed" : 217.9,\n' +
    '\t\t\t\t"sliders" : 161,\n' +
    '\t\t\t\t"speed" : 2.767,\n' +
    '\t\t\t\t"spinners" : 0,\n' +
    '\t\t\t\t"star" : 6.936,\n' +
    '\t\t\t\t"strain_aim" : "222222232222333244333443434434342100124323233410000",\n' +
    '\t\t\t\t"strain_speed" : "123223322222222233233332224443232110003433243234000",\n' +
    '\t\t\t\t"version" : "Snow Note\'s Extreme"\n' +
    '\t\t\t},\n' +
    '\t\t\t{\n' +
    '\t\t\t\t"AR" : 9.8,\n' +
    '\t\t\t\t"CS" : 4.2,\n' +
    '\t\t\t\t"HP" : 6.0,\n' +
    '\t\t\t\t"OD" : 9.5,\n' +
    '\t\t\t\t"aim" : 3.76,\n' +
    '\t\t\t\t"audio" : "audio.mp3",\n' +
    '\t\t\t\t"bg" : "spiderdance.jpg",\n' +
    '\t\t\t\t"bid" : 1587275,\n' +
    '\t\t\t\t"circles" : 341,\n' +
    '\t\t\t\t"hit300window" : 0,\n' +
    '\t\t\t\t"img" : "0",\n' +
    '\t\t\t\t"length" : 101,\n' +
    '\t\t\t\t"maxcombo" : 777,\n' +
    '\t\t\t\t"mode" : 0,\n' +
    '\t\t\t\t"passcount" : 41751,\n' +
    '\t\t\t\t"playcount" : 355833,\n' +
    '\t\t\t\t"pp" : 450.4,\n' +
    '\t\t\t\t"pp_acc" : 110.6,\n' +
    '\t\t\t\t"pp_aim" : 212.3,\n' +
    '\t\t\t\t"pp_speed" : 212.3,\n' +
    '\t\t\t\t"sliders" : 189,\n' +
    '\t\t\t\t"speed" : 3.078,\n' +
    '\t\t\t\t"spinners" : 0,\n' +
    '\t\t\t\t"star" : 7.226,\n' +
    '\t\t\t\t"strain_aim" : "243334433334334434444434233432220110113213222221100",\n' +
    '\t\t\t\t"strain_speed" : "023112421132124200100112421211000110100231024414400",\n' +
    '\t\t\t\t"version" : "Kyshiro\'s Genocide"\n' +
    '\t\t\t},\n' +
    '\t\t\t{\n' +
    '\t\t\t\t"AR" : 9.2,\n' +
    '\t\t\t\t"CS" : 3.8,\n' +
    '\t\t\t\t"HP" : 6.0,\n' +
    '\t\t\t\t"OD" : 8.0,\n' +
    '\t\t\t\t"aim" : 2.864,\n' +
    '\t\t\t\t"audio" : "audio.mp3",\n' +
    '\t\t\t\t"bg" : "spiderdance.jpg",\n' +
    '\t\t\t\t"bid" : 1593031,\n' +
    '\t\t\t\t"circles" : 159,\n' +
    '\t\t\t\t"hit300window" : 0,\n' +
    '\t\t\t\t"img" : "0",\n' +
    '\t\t\t\t"length" : 101,\n' +
    '\t\t\t\t"maxcombo" : 657,\n' +
    '\t\t\t\t"mode" : 0,\n' +
    '\t\t\t\t"passcount" : 128169,\n' +
    '\t\t\t\t"playcount" : 653292,\n' +
    '\t\t\t\t"pp" : 194.3,\n' +
    '\t\t\t\t"pp_acc" : 46.85,\n' +
    '\t\t\t\t"pp_aim" : 98.13,\n' +
    '\t\t\t\t"pp_speed" : 98.13,\n' +
    '\t\t\t\t"sliders" : 229,\n' +
    '\t\t\t\t"speed" : 2.108,\n' +
    '\t\t\t\t"spinners" : 0,\n' +
    '\t\t\t\t"star" : 5.332,\n' +
    '\t\t\t\t"strain_aim" : "132213221222213221223332341134433231000012223112000",\n' +
    '\t\t\t\t"strain_speed" : "224223232223213321112222232134433221210013222322200",\n' +
    '\t\t\t\t"version" : "Insane"\n' +
    '\t\t\t}\n' +
    '\t\t],\n' +
    '\t\t"bids_amount" : 11,\n' +
    '\t\t"bpm" : 230.0,\n' +
    '\t\t"creator" : "Fatfan Kolek",\n' +
    '\t\t"creator_id" : 2308676,\n' +
    '\t\t"favourite_count" : 3723,\n' +
    '\t\t"genre" : 2,\n' +
    '\t\t"language" : 5,\n' +
    '\t\t"last_update" : 1524900992,\n' +
    '\t\t"local_update" : 1678708106,\n' +
    '\t\t"preview" : 1,\n' +
    '\t\t"sid" : 750458,\n' +
    '\t\t"source" : "UNDERTALE",\n' +
    '\t\t"storyboard" : 0,\n' +
    '\t\t"tags" : "-kevincela- cheesiest yoeri kyshiro snow note boss fight chiptune soundtrack radiation",\n' +
    '\t\t"title" : "Spider Dance",\n' +
    '\t\t"titleU" : "",\n' +
    '\t\t"video" : 0\n' +
    '\t},\n' +
    '\t"status" : 0\n' +
    '}\n'
function starname(star) {
    if (typeof(star) == "null") return "unknown";
    if (typeof(star) == "undefined") return "unknown";
    if (star<2) return "easy";
    if (star<2.7) return "normal";
    if (star<4) return "hard";
    if (star<5.3) return "insane";
    if (star<6.5) return "expert";
    return "expert-plus";
}

// star: number; numerical representation of star rating
// returns an html element used in difficulty selection menu
function createStarRow(star) {
    let row = document.createElement("div");
    row.className = "star-row";
    for (let i=0; i<10; ++i) {
        let container = document.createElement("div");
        container.className = "imgcontainer";
        let img = document.createElement("img");
        container.appendChild(img);
        row.appendChild(container);
        img.src = "star.png";
        let value = Math.min(Math.max(star-i,0),1);
        let size = 8 + value*10;
        let pad = (1-value) * 5;
        let style = "width:" + size + "px;";
        style += "bottom:" + pad + "px;";
        style += "left:" + pad + "px;";
        if (value == 0) {
            style += "opacity:0.4;";
        }
        img.setAttribute("style", style);
    }
    return row;
}
// creates a difficulty selection menu
function createDifficultyList(boxclicked, event) {
    // check if a list of this kind is already there
    if (window.currentDifficultyList) {
        window.removeEventListener("click", window.currentDifficultyList.clicklistener);
        window.currentDifficultyList.parentElement.removeChild(window.currentDifficultyList);
        window.currentDifficultyList = null;
    }
    // window.showingDifficultyList = true;
    event.stopPropagation();
    // calculate list position on page
    let rect = boxclicked.getBoundingClientRect();
    let x = event.clientX - rect.left;
    let y = event.clientY - rect.top;
    // create list
    let difficultyBox = document.createElement("div");
    window.currentDifficultyList = difficultyBox;
    difficultyBox.className = "difficulty-box";
    difficultyBox.style.left = x + "px";
    difficultyBox.style.top = y + "px";
    boxclicked.appendChild(difficultyBox);
    // close list if clicked outside
    var closeDifficultyList = function() {
        boxclicked.removeChild(difficultyBox);
        window.currentDifficultyList = null;
        window.removeEventListener('click', closeDifficultyList, false);
    };
    window.addEventListener("click", closeDifficultyList, false);
    difficultyBox.clicklistener = closeDifficultyList;
    // fill list
    for (let i=0; i<boxclicked.data.length; ++i) {
        // add a row
        let difficultyItem = document.createElement("div");
        difficultyItem.className = "difficulty-item";
        difficultyBox.appendChild(difficultyItem);
        difficultyItem.data = boxclicked.data[i];
        // add ring icon representing star
        let ringbase = document.createElement("div");
        let ring = document.createElement("div");
        ringbase.className = "bigringbase";
        ring.className = "bigring";
        ring.classList.add(starname(boxclicked.data[i].star));
        difficultyItem.appendChild(ringbase);
        difficultyItem.appendChild(ring);
        // add version name & mapper
        let line = document.createElement("div");
        let version = document.createElement("div");
        let mapper = document.createElement("div");
        line.className = "versionline";
        version.className = "version";
        mapper.className = "mapper";
        line.appendChild(version);
        line.appendChild(mapper);
        difficultyItem.appendChild(line);
        version.innerText = boxclicked.data[i].version;
        mapper.innerText = "mapped by " + boxclicked.data[i].creator;
        // add row of stars
        difficultyItem.appendChild(createStarRow(boxclicked.data[i].star));
        // add callbacks
        difficultyItem.onhover = function() {

        }
        difficultyItem.onclick = function(e) {
            // check if ready
            if (!window.scriptReady || !window.soundReady || !window.skinReady || !this.parentElement.parentElement.oszblob) {
                return;
            }
            launchGame(this.parentElement.parentElement.oszblob, this.data.bid, this.data.version);
        }
    }
    difficultyBox.onclick = function(e) {
        e.stopPropagation();
    }
}


var NSaddBeatmapList = {

    addlikeicon: function(box) {
        let icon = document.createElement("div");
        icon.className = "beatmaplike";
        icon.setAttribute("hidden","");
        box.appendChild(icon);
        box.initlike = function() {
            if (!window.liked_sid_set || !box.sid) {
                return;
            }
            if (window.liked_sid_set.has(box.sid)) {
                icon.classList.add("icon-heart");
                icon.onclick = box.undolike;
            }
            else {
                icon.classList.add("icon-heart-empty");
                icon.onclick = box.like;
            }
            icon.removeAttribute("hidden");
        }
        box.like = function(e) {
            e.stopPropagation();
            window.liked_sid_set.add(box.sid);
            localforage.setItem("likedsidset", window.liked_sid_set, function(err, val){
                if (err) {
                    console.error("Error saving liked beatmap list");
                }
                else {
                    icon.classList.add("hint-liked");
                }
            });
            icon.onclick = box.undolike;
            icon.classList.remove("icon-heart-empty");
            icon.classList.add("icon-heart");
        }
        box.undolike = function(e) {
            e.stopPropagation();
            window.liked_sid_set.delete(box.sid);
            localforage.setItem("likedsidset", window.liked_sid_set, function(err, val){
                if (err) {
                    console.error("Error saving liked beatmap list");
                }
            });
            icon.onclick = box.like;
            icon.classList.remove("icon-heart");
            icon.classList.add("icon-heart-empty");
            icon.classList.remove("hint-liked");
        }
        if (window.liked_sid_set) {
            box.initlike();
        }
        else {
            if (!window.liked_sid_set_callbacks)
                window.liked_sid_set_callbacks = [];
            window.liked_sid_set_callbacks.push(box.initlike);
        }
    },

    // map contains key: sid, title, artist, creator
    addpreviewbox: function(map, list) {
        function approvedText(status) {
            if (status == 4) return "LOVED";
            if (status == 3) return "QUALIFIED";
            if (status == 2) return "APPROVED";
            if (status == 1) return "RANKED";
            if (status == 0) return "PENDING";
            if (status == -1) return "WIP";
            if (status == -2) return "GRAVEYARD";
            return "UNKNOWN";
        }
        // create container of beatmap on web page
        let pBeatmapBox = document.createElement("div");
        pBeatmapBox.setdata = map;
        pBeatmapBox.sid = map.sid;
        let pBeatmapCover = document.createElement("img");
        let pBeatmapCoverOverlay = document.createElement("div");
        let pBeatmapTitle = document.createElement("div");
        let pBeatmapArtist = document.createElement("div");
        let pBeatmapCreator = document.createElement("div");
        let pBeatmapApproved = document.createElement("div");
        pBeatmapBox.className = "beatmapbox";
        pBeatmapCover.className = "beatmapcover";
        pBeatmapCoverOverlay.className = "beatmapcover-overlay";
        pBeatmapTitle.className = "beatmaptitle";
        pBeatmapArtist.className = "beatmapartist";
        pBeatmapCreator.className = "beatmapcreator";
        pBeatmapApproved.className = "beatmapapproved";
        pBeatmapBox.appendChild(pBeatmapCover);
        pBeatmapBox.appendChild(pBeatmapCoverOverlay);
        pBeatmapBox.appendChild(pBeatmapTitle);
        pBeatmapBox.appendChild(pBeatmapArtist);
        pBeatmapBox.appendChild(pBeatmapCreator);
        pBeatmapBox.appendChild(pBeatmapApproved);
        NSaddBeatmapList.addlikeicon(pBeatmapBox);
        // set beatmap title & artist display (prefer ascii title)
        pBeatmapTitle.innerText = map.title;
        pBeatmapArtist.innerText = map.artist;
        pBeatmapCreator.innerText = "mapped by " + map.creator;
        pBeatmapCover.alt = "cover" + map.sid;
        pBeatmapCover.src = "https://cdn.sayobot.cn:25225/beatmaps/" + map.sid + "/covers/cover.webp";
        list.appendChild(pBeatmapBox);
        pBeatmapApproved.innerText = approvedText(map.approved);
        return pBeatmapBox;
    },

    addStarRings: function(box, data) {
        // get star ratings
        let stars = [];
        for (let i=0; i<data.length; ++i) {
            stars.push(data[i].star);
        }
        let row = document.createElement("div");
        row.className = "beatmap-difficulties";
        box.appendChild(row);
        // show all of them if can be fit in
        if (stars.length <= 13) {
            for (let i=0; i<stars.length; ++i) {
                let difficultyRing = document.createElement("div");
                difficultyRing.className = "difficulty-ring";
                let s = starname(stars[i]);
                if (s.length>0)
                    difficultyRing.classList.add(s);
                row.appendChild(difficultyRing);
            }
        }
        // show only highest star and count otherwise
        else {
            let difficultyRing = document.createElement("div");
            difficultyRing.className = "difficulty-ring";
            let s = starname(stars[stars.length-1]);
            if (s.length>0)
                difficultyRing.classList.add(s);
            row.appendChild(difficultyRing);
            let cnt = document.createElement("span");
            cnt.className = "difficulty-count";
            cnt.innerText = stars.length;
            row.appendChild(cnt);
        }
        if (data.length == 0) {
            let cnt = document.createElement("span");
            cnt.className = "difficulty-count";
            cnt.innerText = "no std map";
            row.appendChild(cnt);
        }
    },

    addLength: function(box, data) {
        // show length & bpm
        let length = 0;
        let bpm = 0;
        for (let i=0; i<data.length; ++i) {
            length = Math.max(length, data[i].length);
            bpm = Math.max(bpm, data[i].BPM);
        }
        // let pBeatmapBPM = document.createElement("div");
        // pBeatmapBPM.className = "beatmapbpm";
        // box.appendChild(pBeatmapBPM);
        // pBeatmapBPM.innerText = Math.round(bpm) + "♪";
        let pBeatmapLength = document.createElement("div");
        pBeatmapLength.className = "beatmaplength";
        box.appendChild(pBeatmapLength);
        pBeatmapLength.innerText = Math.floor(length/60) + ":" + (length%60<10?"0":"") + (length%60);
    },

    addMoreInfo: function(box, data) {
        // remove all but osu std mode
        data = data.filter(function(o){return o.mode == 0;});
        data = data.sort(function(a,b){return Math.sign(a.star-b.star);});
        box.data = data;
        NSaddBeatmapList.addStarRings(box, data);
        NSaddBeatmapList.addLength(box, data);
    },

    // async
    requestMoreInfo: function(box) {
        let url = '';
        let xhr = new XMLHttpRequest();
        xhr.responseType = 'text';
        xhr.open("GET", url);
        xhr.onload = function() {
            let res = JSON.parse('{"status":0,"data":[{"bid":1580330,"sid":750458,"title":"Spider Dance","artist":"toby fox","titleU":"","artistU":"","creator":"Fatfan Kolek","source":"UNDERTALE","version":"cheesiest\'s Insane","submitted":1524900992,"ranked":1525484440,"star":4.78682,"CS":4,"AR":9,"HP":6,"OD":8,"maxcombo":625,"mode":0,"aim":2.42015,"speed":2.14226,"pp":159.75,"pp_aim":59.86,"BPM":230,"length":101,"playcount":965358,"passcount":112968,"favourite_count":3723,"img":"0","video":""},{"bid":1580331,"sid":750458,"title":"Spider Dance","artist":"toby fox","titleU":"","artistU":"","creator":"Fatfan Kolek","source":"UNDERTALE","version":"cheesiest\'s Light Insane","submitted":1524900992,"ranked":1525484440,"star":4.2762,"CS":4,"AR":8.5,"HP":5,"OD":7,"maxcombo":563,"mode":0,"aim":2.22206,"speed":1.82625,"pp":102.29,"pp_aim":41.76,"BPM":230,"length":101,"playcount":1333611,"passcount":261972,"favourite_count":3723,"img":"0","video":""},{"bid":1580332,"sid":750458,"title":"Spider Dance","artist":"toby fox","titleU":"","artistU":"","creator":"Fatfan Kolek","source":"UNDERTALE","version":"Easy","submitted":1524900992,"ranked":1525484440,"star":1.59028,"CS":2,"AR":3.3,"HP":2.5,"OD":2.5,"maxcombo":279,"mode":0,"aim":0.854738,"speed":0.624736,"pp":6.16,"pp_aim":2.16,"BPM":230,"length":99,"playcount":367092,"passcount":204057,"favourite_count":3723,"img":"0","video":""},{"bid":1580333,"sid":750458,"title":"Spider Dance","artist":"toby fox","titleU":"","artistU":"","creator":"Fatfan Kolek","source":"UNDERTALE","version":"Hard","submitted":1524900992,"ranked":1525484440,"star":3.55218,"CS":4,"AR":7.8,"HP":4.5,"OD":6,"maxcombo":547,"mode":0,"aim":1.90271,"speed":1.41479,"pp":58.05,"pp_aim":25.65,"BPM":230,"length":101,"playcount":1089153,"passcount":211824,"favourite_count":3723,"img":"0","video":""},{"bid":1580334,"sid":750458,"title":"Spider Dance","artist":"toby fox","titleU":"","artistU":"","creator":"Fatfan Kolek","source":"UNDERTALE","version":"kevincela\'s Extra","submitted":1524900992,"ranked":1525484440,"star":5.79908,"CS":4.2,"AR":9.4,"HP":6,"OD":8,"maxcombo":699,"mode":0,"aim":3.00274,"speed":2.49387,"pp":239.51,"pp_aim":112,"BPM":230,"length":101,"playcount":232353,"passcount":15480,"favourite_count":3723,"img":"0","video":""},{"bid":1580335,"sid":750458,"title":"Spider Dance","artist":"toby fox","titleU":"","artistU":"","creator":"Fatfan Kolek","source":"UNDERTALE","version":"Yoeri\'s Extra","submitted":1524900992,"ranked":1525484440,"star":5.74052,"CS":4,"AR":9.3,"HP":6,"OD":9,"maxcombo":683,"mode":0,"aim":2.8822,"speed":2.59545,"pp":266.96,"pp_aim":108.49,"BPM":230,"length":101,"playcount":319914,"passcount":39870,"favourite_count":3723,"img":"0","video":""},{"bid":1580336,"sid":750458,"title":"Spider Dance","artist":"toby fox","titleU":"","artistU":"","creator":"Fatfan Kolek","source":"UNDERTALE","version":"Yoeri\'s Normal","submitted":1524900992,"ranked":1525484440,"star":2.25521,"CS":3.5,"AR":5,"HP":4,"OD":5,"maxcombo":355,"mode":0,"aim":1.19551,"speed":0.921252,"pp":21.06,"pp_aim":6.97,"BPM":230,"length":101,"playcount":958815,"passcount":317979,"favourite_count":3723,"img":"0","video":""},{"bid":1582339,"sid":750458,"title":"Spider Dance","artist":"toby fox","titleU":"","artistU":"","creator":"Fatfan Kolek","source":"UNDERTALE","version":"Kyshiro\'s Extreme","submitted":1524900992,"ranked":1525484440,"star":6.21829,"CS":4.2,"AR":9.5,"HP":6,"OD":9.2,"maxcombo":742,"mode":0,"aim":3.25098,"speed":2.62447,"pp":321.78,"pp_aim":146.5,"BPM":230,"length":101,"playcount":299367,"passcount":26937,"favourite_count":3723,"img":"0","video":""},{"bid":1584604,"sid":750458,"title":"Spider Dance","artist":"toby fox","titleU":"","artistU":"","creator":"Fatfan Kolek","source":"UNDERTALE","version":"Snow Note\'s Extreme","submitted":1524900992,"ranked":1525484440,"star":6.93563,"CS":3.5,"AR":9.6,"HP":6,"OD":9.3,"maxcombo":776,"mode":0,"aim":3.71437,"speed":2.76749,"pp":423.08,"pp_aim":217.94,"BPM":230,"length":101,"playcount":548946,"passcount":24813,"favourite_count":3723,"img":"0","video":""},{"bid":1587275,"sid":750458,"title":"Spider Dance","artist":"toby fox","titleU":"","artistU":"","creator":"Fatfan Kolek","source":"UNDERTALE","version":"Kyshiro\'s Genocide","submitted":1524900992,"ranked":1525484440,"star":7.22568,"CS":4.2,"AR":9.8,"HP":6,"OD":9.5,"maxcombo":777,"mode":0,"aim":3.76027,"speed":3.07813,"pp":450.41,"pp_aim":212.32,"BPM":230,"length":101,"playcount":355833,"passcount":41751,"favourite_count":3723,"img":"0","video":""},{"bid":1593031,"sid":750458,"title":"Spider Dance","artist":"toby fox","titleU":"","artistU":"","creator":"Fatfan Kolek","source":"UNDERTALE","version":"Insane","submitted":1524900992,"ranked":1525484440,"star":5.33157,"CS":3.8,"AR":9.2,"HP":6,"OD":8,"maxcombo":657,"mode":0,"aim":2.86448,"speed":2.10795,"pp":194.33,"pp_aim":98.13,"BPM":230,"length":101,"playcount":653292,"passcount":128169,"favourite_count":3723,"img":"0","video":""}]}\n');
            NSaddBeatmapList.addMoreInfo(box, res.data);
        }
        xhr.send();
    }
}


// async
// adds symbols of these beatmap packs to webpage
// listurl: url of api request that returns a list of beatmap packs
// list: DOM element to insert beatmaps into
// filter, maxsize: does't apply if not specified
// Note that some beatmaps may not contain std mode, so we request more maps than we need
function addBeatmapList(listurl, list, filter, maxsize) {
    if (!list) list = document.getElementById("beatmap-list");
    // request beatmap pack list
    let xhr = new XMLHttpRequest();
    xhr.responseType = 'text';
    xhr.open("GET", '');
    // async part 1
    xhr.onload = function() {
        let res = JSON.parse('{\n' +
            '  "data": [\n' +
            '    {\n' +
            '      "approved": 1,\n' +
            '      "artist": "toby fox",\n' +
            '      "artistU": "",\n' +
            '      "creator": "fatfan",\n' +
            '      "favourite_count": 9840,\n' +
            '      "lastupdate": 1546156130,\n' +
            '      "modes": 11,\n' +
            '      "order": 8.84,\n' +
            '      "play_count": 79246602,\n' +
            '      "sid": 750458,\n' +
            '      "title": "Spider Dance",\n' +
            '      "titleU": "quaver ?"\n' +
            '    }\n' +
            '  ],\n' +
            '  "endid": 4,\n' +
            '  "status": 0\n' +
            '}');
        if (typeof(res.endid) != "undefined")
            window.list_endid = res.endid;
        else {
            window.list_endid = 0;
            return;
        }
        let box = [];
        if (filter && res.data) {
            res.data = res.data.filter(filter);
        }
        if (maxsize && res.data) {
            res.data = res.data.slice(0, maxsize);
        }
        // add widget to webpage as soon as list is fetched
        for (let i=0; i<res.data.length; ++i) {
            box.push(NSaddBeatmapList.addpreviewbox(res.data[i], list));
        }
        // async add more info
        for (let i=0; i<res.data.length; ++i) {
            box[i].sid = res.data[i].sid;
            NSaddBeatmapList.requestMoreInfo(box[i]);
            box[i].onclick = function(e) {
                // this is effective only when box.data is available
                createDifficultyList(box[i], e);
                startdownload(box[i]);
            }
        }
        if (window.beatmaplistLoadedCallback) {
            window.beatmaplistLoadedCallback();
            window.beatmaplistLoadedCallback = null;
            // to make sure it's called only once
        }
    }
    xhr.send();
}

function addBeatmapSid(sid, list) {

    if (!list) list = document.getElementById("beatmap-list");
    let url = '';
    let xhr = new XMLHttpRequest();
    xhr.responseType = 'text';
    xhr.open("GET", url);
    xhr.onload = function() {
        let res = JSON.parse(window.songInfo);
        if (res.status==-1) {
            alert("Beatmap not found with specified sid");
            return;
        }
        // use data of first track as set data
        let box = NSaddBeatmapList.addpreviewbox(res.data, list);
        box.sid = res.data.sid;
        NSaddBeatmapList.requestMoreInfo(box);
        box.onclick = function(e) {
            // this is effective only when box.data is available
            createDifficultyList(box, e);
            startdownload(box);
        }
        if (window.beatmaplistLoadedCallback) {
            window.beatmaplistLoadedCallback();
            window.beatmaplistLoadedCallback = null;
            // to make sure it's called only once
        }
    }
    xhr.send();
}



