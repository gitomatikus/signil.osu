ffmpeg -i drum-hitnormal.wav drum-hitnormal.ogg
ffmpeg -i drum-hitwhistle.wav drum-hitwhistle.ogg
ffmpeg -i drum-hitfinish.wav drum-hitfinish.ogg
ffmpeg -i drum-hitclap.wav drum-hitclap.ogg
ffmpeg -i drum-sliderslide.wav drum-sliderslide.ogg
ffmpeg -i drum-sliderwhistle.wav drum-sliderwhistle.ogg
ffmpeg -i drum-slidertick.wav drum-slidertick.ogg

ffmpeg -i normal-hitnormal.wav normal-hitnormal.ogg
ffmpeg -i normal-hitwhistle.wav normal-hitwhistle.ogg
ffmpeg -i normal-hitfinish.wav normal-hitfinish.ogg
ffmpeg -i normal-hitclap.wav normal-hitclap.ogg
ffmpeg -i normal-sliderslide.wav normal-sliderslide.ogg
ffmpeg -i normal-sliderwhistle.wav normal-sliderwhistle.ogg
ffmpeg -i normal-slidertick.wav normal-slidertick.ogg

ffmpeg -i soft-hitnormal.wav soft-hitnormal.ogg
ffmpeg -i soft-hitwhistle.wav soft-hitwhistle.ogg
ffmpeg -i soft-hitfinish.wav soft-hitfinish.ogg
ffmpeg -i soft-hitclap.wav soft-hitclap.ogg
ffmpeg -i soft-sliderslide.wav soft-sliderslide.ogg
ffmpeg -i soft-sliderwhistle.wav soft-sliderwhistle.ogg
ffmpeg -i soft-slidertick.wav soft-slidertick.ogg
